<?php if($histori->isEmpty()): ?>
    <div class="alert alert-outline-warning">
        <p>Data Belum Ada</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered table-striped text-center">
            <thead class="table-primary">
                <tr>
                    <th>Tanggal</th>
                    <th>Jam Masuk</th>
                    <th>Jam Pulang</th>
                    <th>Total Jam Kerja</th>
                    <th>Catatan Harian</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- <?php
                                        // Hitung total jam kerja
                                        $jamMasuk = \Carbon\Carbon::parse($d->jam_in);
                                        $jamPulang = \Carbon\Carbon::parse($d->jam_out);
                                        $totalJamKerja = $jamMasuk->diff($jamPulang)->format('%H:%I:%S');
                                    ?> -->

                        <?php
                            $jamMasuk = \Carbon\Carbon::parse($d->jam_in);
                            $totalJamKerja = 'Belum Absen Pulang';

                            // Cek jika jam pulang tersedia, maka hitung total jam kerja
                            if (!empty($d->jam_out)) {
                                $jamPulang = \Carbon\Carbon::parse($d->jam_out);
                                $totalJamKerja = $jamMasuk->diff($jamPulang)->format('%H:%I:%S');
                            }
                        ?>
                        <tr>
                            <td><?php echo e(date("d-m-Y", strtotime($d->tgl_presensi))); ?></td>
                            <td><?php echo e($d->jam_in); ?></td>
                            <td><?php echo e($d->jam_out); ?></td>
                            <td><?php echo e($totalJamKerja); ?></td>
                            <td><?php echo e($d->catat_harian ?? '-'); ?></td>
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>


<!-- <?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->
<!-- <ul class="listview image-listview">
        <li>
            <div class="item">
                <?php
                    $path = Storage::url('uploads/absensi/' . $d->foto_in);
                ?> -->
<!-- <img src="<?php echo e(url($path)); ?>" alt="image" class="image"> -->
<!-- <div class="in">
                    <div>
                        <b><?php echo e(date("d-m-Y", strtotime($d->tgl_presensi))); ?></b><br>
                        <small class="text-muted"><?php echo e($d->prodi); ?></small>
                    </div>
                    <span class="badge <?php echo e($d->jam_in < "07.30" ? "bg-success" : "bg-danger"); ?>" style="color : aliceblue;">
                        <?php echo e($d->jam_in); ?>

                    </span>
                    <span class="badge bg-primary" style="color : aliceblue;"><?php echo e($d->jam_out); ?></span>
                </div>
            </div>
        </li>
    </ul> -->

<!-- <table>
        <th>Tanggal</th>
        <th>Jam Masuk</th>
        <th>Jam Pulang</th>
        <th>Total Jam Kerja</th>
        <tr>
            <td><?php echo e(date("d-m-Y", strtotime($d->tgl_presensi))); ?></td>
            <td><?php echo e($d->jam_in); ?></td>
            <td><?php echo e($d->jam_out); ?></td>
            <td><?php echo e($total_waktu); ?></td>

        </tr>
    </table>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> --><?php /**PATH D:\SKRIPSI\presensi\resources\views/presensi/gethistori.blade.php ENDPATH**/ ?>