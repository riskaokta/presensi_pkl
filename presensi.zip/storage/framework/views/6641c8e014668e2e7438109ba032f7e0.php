<?php $__env->startSection('content'); ?>
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle">
                    Mahasiswa
                </div>
                <h2 class="page-title">
                    Data Mahasiswa
                </h2>
            </div>
        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="col-12">
                            <a href="#" class="btn btn-primary" id="btnTambahkaryawan">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round"
                                    class="icon icon-tabler icons-tabler-outline icon-tabler-plus">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                    <path d="M12 5l0 14" />
                                    <path d="M5 12l14 0" />
                                </svg>Tambah Data</a>
                        </div>
                        <div class="row mt-2">
                            <div class="col-12">
                                <form action="/mahasiswa" method="GET">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <input type="text" name="nama_mahasiswa" id="nama_mahasiswa"
                                                    class="form-control" placeholder="Nama Mahasiswa"
                                                    value="<?php echo e(Request('nama_mhs')); ?>">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <select name="prodi" id="prodi" class="form-control"> //ini seharusnya
                                                    form select
                                                    <option value="">Program Studi</option>
                                                    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php echo e(Request('prodi') == $d->prodi ? 'selected' : ''); ?>

                                                            value="<?php echo e($d->prodi); ?>"><?php echo e($d->prodi); ?></option> //search belum
                                                        jalan
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-2">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary"><svg
                                                        xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                        viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                        class="icon icon-tabler icons-tabler-outline icon-tabler-search">
                                                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                        <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
                                                        <path d="M21 21l-6 -6" />
                                                    </svg>
                                                    Cari</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col">
                            <div class="row mt-2">
                                <div class="col-12">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>NPM</th>
                                                <th>Nama</th>
                                                <th>Program Studi</th>
                                                <th>No HP</th>
                                                <th>Foto</th>
                                                <th>Tempat PKL</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php
                                                                                            $path = Storage::url('uploads/mahasiswa/' . $d->foto)
                                                                                        ?>
                                                                                        <tr>
                                                                                            <td><?php echo e($loop->iteration + $mahasiswa->firstItem() - 1); ?></td>
                                                                                            <td><?php echo e($d->npm); ?></td>
                                                                                            <td><?php echo e($d->nama_mhs); ?></td>
                                                                                            <td><?php echo e($d->prodi); ?></td>
                                                                                            <td><?php echo e($d->nohp_mhs); ?></td>
                                                                                            <!-- foto belum muncul -->
                                                                                            <td>
                                                                                                <?php if(empty($d->foto)): ?>
                                                                                                    <img src="<?php echo e(asset('assets/img/nopoto.png')); ?>" class="avatar"
                                                                                                        alt="" width="50" height="50">
                                                                                                <?php else: ?>
                                                                                                    <img src="<?php echo e(url($path)); ?>" class="avatar" alt="" width="50"
                                                                                                        height="50">
                                                                                                <?php endif; ?>
                                                                                            </td>
                                                                                            <td><?php echo e($d->tempat_pkl); ?></td>
                                                                                            <td></td>
                                                                                        </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <!-- pagination belum muncul -->
                                    <?php echo e($mahasiswa->links('vendor.pagination.bootstrap-5')); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal modal-blur fade show" id="modal-inputmahasiswa" tabindex="-1" role="dialog" aria-modal="true" style="display: block; padding-left: 0px;">
	<div class="modal-dialog modal-1 modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
	<h5 class="modal-title">Modal title</h5>
	<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci animi beatae delectus deleniti dolorem eveniet facere fuga iste nemo nesciunt nihil odio perspiciatis, quia quis reprehenderit sit tempora totam unde.
</div>
<div class="modal-footer">
	<button type="button" class="btn me-auto" data-bs-dismiss="modal">Close</button>
	<button type="button" class="btn btn-primary" data-bs-dismiss="modal">Save changes</button>
</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('myscript'); ?>
<script>
    $(function(){
    $("#btnTambahkaryawan").click(function(){
        $("#modal-inputkaryawan").modal("show"); //modalnya masih blm di tambah
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.tabler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OTW S.KOM\absensi\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>