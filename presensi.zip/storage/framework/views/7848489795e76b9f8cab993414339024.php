<?php $__env->startSection('content'); ?>
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <div class="page-pretitle">Mahasiswa</div>
                <h2 class="page-title">Laporan Presensi</h2>
            </div>
        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm border-light bg-dark text-white p-4">
                    <div class="card-body">
                        <form action="/presensi/cetakrekap" target="_blank" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="bulan" class="form-label">Bulan</label>
                                <select name="bulan" id="bulan" class="form-select w-100">
                                    <option value="">Pilih Bulan</option>
                                    <?php for($i = 1; $i <= 12; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e(date("m") == $i ? 'selected' : ''); ?>><?php echo e($namabulan[$i]); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="tahun" class="form-label">Tahun</label>
                                <select name="tahun" id="tahun" class="form-select w-100">
                                    <option value="">Pilih Tahun</option>
                                    <?php
                                        $tahunmulai = 2024;
                                        $tahunskrg = date("Y");
                                    ?>
                                    <?php for($tahun = $tahunmulai; $tahun <= $tahunskrg; $tahun++): ?>
                                        <option value="<?php echo e($tahun); ?>" <?php echo e(date("Y") == $tahun ? 'selected' : ''); ?>><?php echo e($tahun); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="d-flex justify-content-between gap-5 mt-4">
                                <button type="submit"
                                    class="btn btn-primary w-100 d-flex align-items-center justify-content-center">
                                    <i class="fas fa-print me-2"></i> Cetak
                                </button>
                                <button type="button"
                                    class="btn btn-success w-100 d-flex align-items-center justify-content-center">
                                    <i class="fas fa-file-excel me-2"></i> Export to Excel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.tabler', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\presensi\resources\views/presensi/rekap.blade.php ENDPATH**/ ?>