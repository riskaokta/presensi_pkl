<?php if($histori->isEmpty()): ?>
    <div class="alert alert-outline-warning">
        <p>Data Belum Ada</p>
    </div>
<?php endif; ?>

<?php $__currentLoopData = $histori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul class="listview image-listview">
        <li>
            <div class="item">
                <?php
                    $path = Storage::url('uploads/absensi/' . $d->foto_in);
                ?>
                <img src="<?php echo e(url($path)); ?>" alt="image" class="image">
                <div class="in">
                    <div>
                        <b><?php echo e(date("d-m-Y", strtotime($d->tgl_presensi))); ?></b><br>
                        <small class="text-muted"><?php echo e($d->prodi); ?></small>
                    </div>
                    <span class="badge <?php echo e($d->jam_in < "07.30" ? "bg-success" : "bg-danger"); ?>" style="color : aliceblue;">
                        <?php echo e($d->jam_in); ?>

                    </span>
                    <span class="badge bg-primary" style="color : aliceblue;"><?php echo e($d->jam_out); ?></span>
                </div>
            </div>
        </li>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\OTW S.KOM\absensi\resources\views/presensi/gethistori.blade.php ENDPATH**/ ?>