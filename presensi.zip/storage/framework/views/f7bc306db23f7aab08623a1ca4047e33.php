<?php $__env->startSection('header'); ?>
<!-- App Header -->
<div class="appHeader bg-primary text-light">
    <div class="left">
        <a href="javascript:;" class="headerButton goBack">
            <ion-icon name="chevron-back-outline"></ion-icon>
        </a>
    </div>
    <div class="pageTitle">Data Izin / Sakit</div>
    <div class="right"></div>
</div>
<!-- App Header -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0" style="margin-top: 10px;">
    <div class="row mx-0">
        <div class="col px-2">
            <?php
                $messagesuccess = Session::get('success');
                $messageerror = Session::get('error');
            ?>
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success mt-2">
                    <?php echo e($messagesuccess); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::get('error')): ?>
                <div class="alert alert-danger mt-2">
                    <?php echo e($messageerror); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Memberi jarak antara header dan tabel -->
    <div class="row mx-0 mt-3">
        <div class="col px-2">
            <table class="table table-striped table-bordered" style="margin: 0; width: 100%;">
                <thead style="background-color: white; color: black; border-bottom: 2px solid #dee2e6;">
                    <tr>
                        <th>#</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Lampiran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $dataizin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tgl_izin))); ?></td>
                            <td><?php echo e($d->status == 's' ? 'Sakit' : 'Izin'); ?></td>
                            <td><?php echo e($d->lampiran); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">Belum ada data izin/sakit.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- FAB Button -->
<div class="fab-button bottom-right" style="margin-bottom:70px; display: flex; justify-content: center; align-items: center;">
    <a href="/presensi/buatizin" 
       class="fab btn btn-primary btn-lg rounded-circle shadow d-flex justify-content-center align-items-center" 
       style="width: 70px; height: 70px; font-size: 48px; position: relative;">
        <ion-icon name="add-outline" style="font-size: 36px; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"></ion-icon>
    </a>
</div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.absensi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SKRIPSI\presensi\resources\views/presensi/izin.blade.php ENDPATH**/ ?>